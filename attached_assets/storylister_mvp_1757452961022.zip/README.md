
# Storylister (MVP)

Search, filter, flag, and **capture to your own Google Sheet** the Instagram Story viewers that **you** can see in the native viewer dialog (visible for ~48 hours after posting).

- **No background automation.** You stay in control. Press and **hold** a button to keep loading more; release to stop.
- **Your data stays yours.** Pro writes to a Google Sheet **in your own Drive** using minimal scopes.

> ⚠️ Instagram shows story viewer identities to the story author for **up to 48 hours** after posting. After that, the viewer list is no longer available. See: Instagram Help Center.


## Install (developer mode)

1. Download this repo and unzip.
2. Go to `chrome://extensions` → toggle **Developer mode** (top right).
3. Click **Load unpacked** → select the folder.
4. Open `instagram.com`, post a story, open the **viewer list**, and the panel should appear.
5. Use **Hold to load** to keep scrolling while you hold the button. **Search** and **flag** people.
6. Click **Capture → Sheet (Pro)** to send the indexed viewers to a new Google Sheet in your Drive.

## Google OAuth Setup (to enable Pro Capture)

You need a Google Cloud project with **Drive API** and **Sheets API** enabled, and an OAuth 2.0 **Web application** client. 

- Set the authorized redirect URI to: `https://<your-extension-id>.chromiumapp.org/oauth2` (you can generate this with `chrome.identity.getRedirectURL("oauth2")`).
- Paste your Client ID into `src/background.js` (`GOOGLE_CLIENT_ID`), then reload the extension.

## Data model (Sheet)

**Sheet**: `view_events`

| captured_at | story_id | username | display_name | seen_order | session_id | flags | notes |
|---|---|---|---|---|---|---|---|

Additional tabs: `profiles`, `watchlist`, `metrics`, `dashboard` (seeded).

## What Storylister does **not** do

- It does **not** run invisible background scraping, auto-scroll without you holding a button, or attempt to evade platform detection. You must have the viewer dialog open and present.
- It does **not** fetch private or off-screen data. It only indexes what appears in the DOM while you scroll.

## Licensing (paid)

Wire up Stripe + ExtensionPay or your preferred licensing to gate the **Capture → Sheet** feature.

## Known limitations

- Instagram may change the viewer dialog DOM; selectors here are designed to be tolerant, but adjustments may be required.
- The viewer list is paginated by Instagram; for very large accounts, you may need to hold-to-load in a few passes inside the 48h window.

## Legal & policy

- Respect Instagram terms. Avoid any automated data collection beyond explicit, continuous user action. 
- Chrome Web Store requires an accurate privacy policy and clear disclosures of data use. Host `/privacy` on your site and link it in the store listing.

(c) 2025 Storylister
