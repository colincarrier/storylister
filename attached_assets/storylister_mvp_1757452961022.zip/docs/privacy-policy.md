
# Storylister – Privacy Policy (MVP)

Storylister reads the visible Instagram Story viewer list **only while you have it open** on instagram.com to provide search, filters, flags, and user‑initiated capture to a Google Sheet **in your own Google Drive**.

**What we collect**
- On-device only: usernames, display names, and basic flags you set while using the panel.
- When you click **Capture → Sheet**, the extension writes those rows directly to *your* Google Sheet using the Google Drive/Sheets APIs.

**What we don't collect**
- We do not run background scraping.
- We do not transmit your Instagram session or viewer data to our servers. By default, no servers are involved.

**Permissions**
- `activeTab` and `host_permissions` for instagram.com to render the panel you use.
- `identity` only to let you connect *your* Google account for Drive/Sheets. Scopes are limited to `drive.file` (files you create/open with Storylister) and `spreadsheets`.

**Data retention**
- Local flags and preferences are stored in your browser (IndexedDB / storage). You can clear them anytime.
- Your Google Sheet is owned by you and stored in your Google Drive.

Contact: support@storylister.com
