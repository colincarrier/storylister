
# Storylister – Terms of Use (MVP)

By using Storylister, you agree to:

1. Use the extension only in ways permitted by the sites you visit.
2. Keep all data you capture within your own Google account unless you choose to share it.
3. Not rely on Storylister for any purpose prohibited by law or platform policies.

Storylister is provided “as is” without warranties. You are responsible for how you use it and for complying with Instagram’s and Google’s terms.
