
// Storylister background (service worker)
const OAUTH_SCOPES = [
  "https://www.googleapis.com/auth/drive.file",
  "https://www.googleapis.com/auth/spreadsheets"
].join(" ");

// NOTE: Replace this with your Google OAuth client ID once created.
let GOOGLE_CLIENT_ID = "YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com";

async function getRedirectURL() {
  return chrome.identity.getRedirectURL("oauth2");
}

async function launchGoogleOAuth() {
  const redirectUri = await getRedirectURL();
  const authUrl = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  authUrl.searchParams.set("client_id", GOOGLE_CLIENT_ID);
  authUrl.searchParams.set("response_type", "token");
  authUrl.searchParams.set("redirect_uri", redirectUri);
  authUrl.searchParams.set("scope", OAUTH_SCOPES);
  authUrl.searchParams.set("prompt", "consent");
  authUrl.searchParams.set("include_granted_scopes", "true");

  const responseUrl = await chrome.identity.launchWebAuthFlow({
    url: authUrl.toString(),
    interactive: true
  });

  // Token is in the fragment (#access_token=...)
  const hash = new URL(responseUrl).hash.substring(1);
  const params = new URLSearchParams(hash);
  const accessToken = params.get("access_token");
  if (!accessToken) throw new Error("No access token returned");
  await chrome.storage.local.set({ "sl_google_access_token": accessToken, "sl_token_obtained_at": Date.now() });
  return accessToken;
}

async function getAccessToken() {
  const { sl_google_access_token } = await chrome.storage.local.get("sl_google_access_token");
  if (sl_google_access_token) return sl_google_access_token;
  return launchGoogleOAuth();
}

async function apiFetch(url, options = {}) {
  const token = await getAccessToken();
  const res = await fetch(url, {
    ...options,
    headers: {
      "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json",
      ...(options.headers || {})
    }
  });
  if (res.status === 401) {
    // Try to refresh token flow
    await chrome.storage.local.remove(["sl_google_access_token"]);
    return apiFetch(url, options);
  }
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`API error ${res.status}: ${text}`);
  }
  return res.json();
}

// Create spreadsheet in user's Drive (Drive API v3)
async function createSpreadsheetInDrive(name = "Storylister Viewers") {
  const meta = {
    name,
    mimeType: "application/vnd.google-apps.spreadsheet"
  };
  const createRes = await apiFetch("https://www.googleapis.com/drive/v3/files", {
    method: "POST",
    body: JSON.stringify(meta)
  });
  const spreadsheetId = createRes.id;

  // Add headers to 'view_events' sheet via Sheets API
  await apiFetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
    method: "POST",
    body: JSON.stringify({
      requests: [
        { addSheet: { properties: { title: "view_events" } } },
        { addSheet: { properties: { title: "profiles" } } },
        { addSheet: { properties: { title: "watchlist" } } },
        { addSheet: { properties: { title: "metrics" } } },
        { addSheet: { properties: { title: "dashboard" } } },
        { deleteSheet: { sheetId: 0 } } // remove default Sheet1
      ]
    })
  });

  const headerRow = [["captured_at","story_id","username","display_name","seen_order","session_id","flags","notes"]];
  await apiFetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/view_events!A1:append?valueInputOption=RAW`, {
    method: "POST",
    body: JSON.stringify({ range: "view_events!A1", majorDimension: "ROWS", values: headerRow })
  });

  // Seed simple formulas in metrics
  const metricsSeed = [
    ["metric","description","formula"],
    ["total_rows","Total captured rows","=COUNTA(view_events!A:A)-1"],
    ["unique_viewers","Unique usernames","=COUNTA(UNIQUE(FILTER(view_events!C:C,view_events!C:C<>\"username\")))"]
  ];
  await apiFetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/metrics!A1:append?valueInputOption=RAW`, {
    method: "POST",
    body: JSON.stringify({ range: "metrics!A1", majorDimension: "ROWS", values: metricsSeed })
  });

  return spreadsheetId;
}

async function appendViewEvents(spreadsheetId, rows) {
  // rows: array of arrays
  const body = { range: "view_events!A1", majorDimension: "ROWS", values: rows };
  return apiFetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/view_events!A1:append?valueInputOption=USER_ENTERED`, {
    method: "POST",
    body: JSON.stringify(body)
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (msg.type === "sl.oauth") {
        const token = await getAccessToken();
        sendResponse({ ok: true, token });
      } else if (msg.type === "sl.createSheet") {
        const id = await createSpreadsheetInDrive(msg.name || "Storylister Viewers");
        await chrome.storage.local.set({ "sl_spreadsheet_id": id });
        sendResponse({ ok: true, spreadsheetId: id });
      } else if (msg.type === "sl.appendRows") {
        const { spreadsheetId } = await chrome.storage.local.get("sl_spreadsheet_id");
        if (!spreadsheetId) throw new Error("No spreadsheet configured. Create one first.");
        await appendViewEvents(spreadsheetId, msg.rows);
        sendResponse({ ok: true });
      } else if (msg.type === "sl.getSpreadsheetId") {
        const { sl_spreadsheet_id } = await chrome.storage.local.get("sl_spreadsheet_id");
        sendResponse({ ok: true, spreadsheetId: sl_spreadsheet_id || null });
      } else if (msg.type === "sl.setClientId") {
        GOOGLE_CLIENT_ID = msg.clientId;
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false, error: "Unknown message" });
      }
    } catch (e) {
      sendResponse({ ok: false, error: String(e) });
    }
  })();
  return true; // keep the message channel open for async
});
