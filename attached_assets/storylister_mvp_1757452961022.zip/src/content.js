
// Storylister content script
(function(){
  const PANEL_ID = "storylister-panel";

  // Utility: create element with classes
  function el(tag, className, text) {
    const e = document.createElement(tag);
    if (className) e.className = className;
    if (text) e.textContent = text;
    return e;
  }

  // Build side panel
  function ensurePanel() {
    let panel = document.getElementById(PANEL_ID);
    if (panel) return panel;

    panel = el("div");
    panel.id = PANEL_ID;
    panel.style.position = "fixed";
    panel.style.top = "64px";
    panel.style.right = "16px";
    panel.style.width = "320px";
    panel.style.maxHeight = "80vh";
    panel.style.overflow = "hidden";
    panel.style.background = "white";
    panel.style.border = "1px solid rgba(0,0,0,0.12)";
    panel.style.borderRadius = "8px";
    panel.style.boxShadow = "0 8px 24px rgba(0,0,0,0.2)";
    panel.style.fontFamily = "system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif";
    panel.style.zIndex = 999999;

    const header = el("div");
    header.style.padding = "8px 12px";
    header.style.borderBottom = "1px solid #eee";
    header.style.display = "flex";
    header.style.alignItems = "center";
    header.style.gap = "8px";

    const title = el("div", null, "Storylister");
    title.style.fontWeight = "600";
    title.style.flex = "1";

    const closeBtn = el("button", null, "×");
    closeBtn.style.border = "none";
    closeBtn.style.background = "transparent";
    closeBtn.style.fontSize = "18px";
    closeBtn.style.cursor = "pointer";
    closeBtn.onclick = () => panel.remove();

    header.append(title, closeBtn);

    const controls = el("div");
    controls.style.padding = "8px 12px";
    controls.style.display = "grid";
    controls.style.gridTemplateColumns = "1fr";
    controls.style.gap = "8px";

    const search = el("input");
    search.type = "search";
    search.placeholder = "Search username or name...";
    search.style.padding = "8px";
    search.style.border = "1px solid #ddd";
    search.style.borderRadius = "6px";
    controls.appendChild(search);

    // Flags
    const flagsRow = el("div");
    flagsRow.style.display = "flex";
    flagsRow.style.gap = "8px";

    const chkNew = el("input"); chkNew.type = "checkbox";
    const lblNew = el("label", null, "New this session"); lblNew.style.fontSize="12px";
    lblNew.prepend(chkNew);
    const chkFlagged = el("input"); chkFlagged.type = "checkbox";
    const lblFlagged = el("label", null, "Flagged"); lblFlagged.style.fontSize="12px";
    lblFlagged.prepend(chkFlagged);

    flagsRow.append(lblNew, lblFlagged);
    controls.appendChild(flagsRow);

    const watchlistTA = el("textarea");
    watchlistTA.placeholder = "Watchlist usernames (one per line)…";
    watchlistTA.style.minHeight = "60px";
    watchlistTA.style.padding = "6px 8px";
    watchlistTA.style.border = "1px solid #ddd";
    watchlistTA.style.borderRadius = "6px";
    controls.appendChild(watchlistTA);

    const actionsRow = el("div");
    actionsRow.style.display = "flex";
    actionsRow.style.gap = "8px";

    const holdBtn = el("button", null, "Hold to load");
    holdBtn.style.flex = "1";
    holdBtn.style.padding = "8px";
    holdBtn.style.border = "1px solid #ddd";
    holdBtn.style.borderRadius = "6px";
    holdBtn.style.cursor = "pointer";

    const captureBtn = el("button", null, "Capture → Sheet (Pro)");
    captureBtn.style.flex = "1";
    captureBtn.style.padding = "8px";
    captureBtn.style.border = "1px solid #ddd";
    captureBtn.style.borderRadius = "6px";
    captureBtn.style.cursor = "pointer";

    actionsRow.append(holdBtn, captureBtn);
    controls.appendChild(actionsRow);

    const status = el("div", null, "Ready on this page");
    status.style.padding = "6px 12px";
    status.style.borderTop = "1px solid #eee";
    status.style.fontSize = "12px";
    status.style.color = "#555";

    const list = el("div");
    list.style.overflow = "auto";
    list.style.maxHeight = "48vh";
    list.style.borderTop = "1px solid #eee";

    panel.append(header, controls, list, status);
    document.body.appendChild(panel);

    // State
    const seen = new Map(); // username -> {displayName, flagged, firstSeen, lastSeen}
    let sessionId = Date.now().toString(36);
    let observer;
    let holdInterval = null;

    function getWatchlist() {
      const raw = watchlistTA.value || "";
      return new Set(raw.split(/\s+/).map(s=>s.trim()).filter(Boolean).map(s=>s.replace(/^@/, "")));
    }

    // Find the viewer list scroller heuristically
    function findViewerScroller() {
      // Look for a dialog with lots of profile links '/<username>/'
      const dialogs = Array.from(document.querySelectorAll('div[role="dialog"],[role="dialog"]'));
      for (const d of dialogs) {
        const anchors = d.querySelectorAll('a[href*="//www.instagram.com/"], a[href^="/"]');
        let usernameCount = 0;
        anchors.forEach(a => {
          const href = a.getAttribute("href") || "";
          if (/^\/[A-Za-z0-9._]+\/$/.test(href)) usernameCount++;
        });
        if (usernameCount > 20) {
          // pick the nearest scrollable parent
          let node = d;
          while (node && node !== document.body) {
            const style = getComputedStyle(node);
            if (/(auto|scroll)/.test(style.overflowY)) return node;
            node = node.parentElement;
          }
          return d;
        }
      }
      return null;
    }

    function indexVisible(scroller) {
      const anchors = scroller.querySelectorAll('a[href^="/"]');
      anchors.forEach(a => {
        const href = a.getAttribute("href") || "";
        const m = href.match(/^\/([A-Za-z0-9._]+)\/$/);
        if (!m) return;
        const username = m[1];
        // Try to extract display name nearby
        let displayName = a.getAttribute("aria-label") || a.textContent.trim();
        if (!displayName || displayName.toLowerCase() === username.toLowerCase()) {
          // look at parent text nodes
          const parentText = a.parentElement ? a.parentElement.textContent.trim() : "";
          if (parentText && parentText.length < 60) displayName = parentText;
        }
        const now = Date.now();
        if (!seen.has(username)) {
          seen.set(username, { displayName, flagged: false, firstSeen: now, lastSeen: now, seenOrder: seen.size+1 });
        } else {
          seen.get(username).lastSeen = now;
        }
      });
      render();
    }

    function render() {
      const q = (search.value || "").toLowerCase();
      const onlyNew = chkNew.checked;
      const onlyFlagged = chkFlagged.checked;
      const watch = getWatchlist();

      const items = [];
      for (const [username, data] of seen.entries()) {
        const flag = data.flagged ? "✓" : "";
        const isNew = data.firstSeen === data.lastSeen;
        if (onlyNew && !isNew) continue;
        if (onlyFlagged && !data.flagged) continue;
        if (q && !(username.toLowerCase().includes(q) || (data.displayName||"").toLowerCase().includes(q))) continue;

        items.push({ username, ...data, watch: watch.has(username) });
      }
      items.sort((a,b)=> a.seenOrder - b.seenOrder);

      list.innerHTML = "";
      const missing = Array.from(watch).filter(u => !seen.has(u));

      if (missing.length) {
        const miss = el("div", null, `Missing viewers from watchlist (${missing.length}): ${missing.slice(0,20).join(", ")}${missing.length>20?"…":""}`);
        miss.style.padding = "8px 12px";
        miss.style.background = "#fffbe6";
        miss.style.borderBottom = "1px solid #eee";
        miss.style.fontSize = "12px";
        list.appendChild(miss);
      }

      items.slice(0,2000).forEach(row => {
        const r = el("div");
        r.style.display = "grid";
        r.style.gridTemplateColumns = "1fr auto";
        r.style.gap = "8px";
        r.style.padding = "8px 12px";
        r.style.borderBottom = "1px solid #f3f3f3";
        const left = el("div", null, `${row.username}${row.watch?" ⭐":""}\n${row.displayName||""}`);
        left.style.whiteSpace = "pre-line";
        left.style.fontSize = "12px";
        const flagBtn = el("button", null, row.flagged ? "Unflag" : "Flag");
        flagBtn.style.fontSize = "12px";
        flagBtn.style.border = "1px solid #ddd";
        flagBtn.style.borderRadius = "4px";
        flagBtn.style.cursor = "pointer";
        flagBtn.onclick = () => { row.flagged = !row.flagged; seen.get(row.username).flagged = row.flagged; render(); };
        r.append(left, flagBtn);
        list.appendChild(r);
      });

      status.textContent = `Indexed ${seen.size} viewer(s). Hold to load more while the Instagram viewer dialog is open.`;
    }

    function startObserving() {
      const scroller = findViewerScroller();
      if (!scroller) {
        status.textContent = "Open your Story viewer list to use Storylister.";
        return;
      }
      // Observe DOM changes
      observer && observer.disconnect();
      observer = new MutationObserver(()=> indexVisible(scroller));
      observer.observe(scroller, { childList: true, subtree: true });
      // Index now
      indexVisible(scroller);

      // Hold-to-load
      const step = () => {
        // Smoothly scroll by a bit
        scroller.scrollBy({ top: 400, behavior: "smooth" });
      };
      holdBtn.onmousedown = () => {
        if (holdInterval) return;
        step();
        holdInterval = setInterval(step, 800);
      };
      const stopHold = () => {
        if (holdInterval) { clearInterval(holdInterval); holdInterval = null; }
      };
      holdBtn.onmouseup = stopHold;
      holdBtn.onmouseleave = stopHold;
      window.addEventListener("blur", stopHold);

      // Capture to Google Sheet
      captureBtn.onclick = async () => {
        // Ensure spreadsheet exists
        let { ok, spreadsheetId } = await chrome.runtime.sendMessage({ type: "sl.getSpreadsheetId" });
        if (!spreadsheetId) {
          const name = prompt("Create a new Google Sheet in your Drive. Name:", "Storylister Viewers");
          if (name === null) return;
          const res = await chrome.runtime.sendMessage({ type: "sl.createSheet", name });
          if (!res.ok) { alert("Failed to create sheet: " + res.error); return; }
          spreadsheetId = res.spreadsheetId;
        }
        const nowIso = new Date().toISOString();
        const rows = [];
        let order = 1;
        for (const [username, data] of seen.entries()) {
          rows.push([nowIso, currentStoryId() || "", username, data.displayName || "", data.seenOrder, sessionId, data.flagged ? "flagged" : "", ""]);
          order++;
        }
        const res2 = await chrome.runtime.sendMessage({ type: "sl.appendRows", rows });
        if (!res2.ok) { alert("Append failed: " + res2.error); return; }
        alert(`Captured ${rows.length} rows to your Google Sheet.`);
      };
    }

    function currentStoryId() {
      // Heuristic: use URL path or the timestamp text if available
      try {
        return location.pathname;
      } catch (e) { return ""; }
    }

    // Kick off when page is ready
    let booted = false;
    const boot = () => {
      if (booted) return;
      booted = true;
      startObserving();
    };
    setInterval(boot, 1500); // lightweight poll to attach when the viewer is opened

    return panel;
  }

  // Auto-mount panel when on instagram.com
  if (location.hostname.endsWith("instagram.com")) {
    ensurePanel();
  }
})();
